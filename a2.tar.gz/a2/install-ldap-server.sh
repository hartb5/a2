#!/bin/bash
#Class: CIT 470
#Team: Team 2
#Professor: Darci Guriel
#Purpose: This will install and configure the LDAP server.
#Authors: Kyle Boger and Brandon Hart

log=ldaplog.log

#HELP COMMAND
if [ "$1" == "-h" ] ; then
    echo "Usage: `basename $0` [Install LDAP Server Script. Run ./install-ldap-server.sh to run the script.]"
    exit 0
fi

#Install OpenLDAP Server and Client Packages  
yum install openldap-servers openldap-clients -y |tee -a $log

hashpw=$(slappasswd -s cit470 -n)
sed -i '/olcSuffix: dc=my-domain,dc=com/c\olcSuffix: dc=cit470,dc=nku,dc=edu' /etc/openldap/slapd.d/cn=config/olcDatabase={2}hdb.ldif
sed -i '/olcRootDN: cn=Manager,dc=my-domain,dc=com/c\olcRootDN: cn=Manager,dc=cit470,dc=nku,dc=edu' /etc/openldap/slapd.d/cn=config/olcDatabase={2}hdb.ldif
echo "olcRootPW: cit470" >> /etc/openldap/slapd.d/cn=config/olcDatabase={2}hdb.ldif
echo "Installing LDAP Servers and Clients from yum." |tee -a $log

#Slapd
systemctl enable slapd |tee -a $log
systemctl start sladpd.service |tee -a $log

#Configure Firewall
systemctl start firewalld.service
firewall-cmd --zone=public --add-port=389/tcp --permanent |tee -a $log
firewall-cmd --zone=public --add-port=636/tcp --permanent |tee -a $log
firewall-cmd --reload |tee -a $log
echo "Firewall configured successfully." |tee -a $log

#Create DB_CONFIG files
rm -R /var/lib/ldap/*
cp /usr/share/openldap-servers/DB_CONFIG.example /var/lib/ldap/DB_CONFIG |tee -a $log
chown -R ldap:ldap /var/lib/ldap |tee -a $log
echo "Created DB_CONFIG file and set ownership." |tee -a $log

#Install nss_ldap package
yum install nss_ldap -y |tee -a $log
echo "Installed nss_ldap from yum." |tee -a $log

#Install migration tools
yum install migrationtools -y |tee -a $log
echo "Installed migration tools." |tee -a $log

#Backup and edit migrate_common
cp /usr/share/migrationtools/migrate_common.ph /usr/share/migrationtools/migrate_common.ph.BAK |tee -a $log
mv migrate_common.ph /usr/share/migrationtools/migrate_common.ph |tee -a $log
echo y
echo "Migrate_common edited successfully." |tee -a $log

#Copy over base.ldif file
mv base.ldif /usr/share/migrationtools/base.ldif
echo "Base.ldif file copied successfully." |tee -a $log

#Add schema
systemctl restart slapd.service |tee -a $log
ldapadd -Y EXTERNAL -H ldapi:// -f /etc/openldap/schema/core.ldif |tee -a $log
ldapadd -Y EXTERNAL -H ldapi:// -f /etc/openldap/schema/cosine.ldif |tee -a $log
ldapadd -Y EXTERNAL -H ldapi:// -f /etc/openldap/schema/nis.ldif |tee -a $log
ldapadd -Y EXTERNAL -H ldapi:// -f /etc/openldap/schema/inetorgperson.ldif |tee -a $log
systemctl stop slapd.service |tee -a $log
chown -R ldap:ldap /var/lib/ldap |tee -a $log
echo "Schemas successfully added." |tee -a $log

#Add in base.ldif data
slapadd -v -l /usr/share/migrationtools/base.ldif |tee -a $log
echo "Successfully added in base data." |tee -a $log

#Diradm
mv diradm.conf /usr/local |tee -a $log
echo "Diradm.conf file succesfully moved." |tee -a $log

#Data migration
currentdir="$(pwd)" |tee -a $log
cd /usr/share/migrationtools

./migrate_passwd.pl /etc/passwd > passwd.ldif |tee -a "${currentdir}/log" |tee -a $log
slapadd -v -l passwd.ldif |tee -a "${currentdir}/log" |tee -a $log
./migrate_group.pl /etc/group > group.ldif |tee -a "${currentdir}/log" |tee -a $log
slapadd -v -l group.ldif |tee -a "${currentdir}/log" |tee -a $log
cd ${currentdir} |tee -a $log
chown -R ldap.ldap /var/lib/ldap |tee -a $log
systemctl start slapd.service |tee -a $log
echo "Data successfully migrated." |tee -a $log

#Finished
echo "LDAP Server Install successfully completed." |tee -a $log
