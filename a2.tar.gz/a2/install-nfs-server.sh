#!/bin/bash
#Class: CIT 470
#Team: Team 2
#Professor: Darci Guriel
#Purpose: This will install and configure NFS.
#Authors: Brandon Hart, Sarah Martin, and Kyle Boger

log=nfslog.log

#HELP COMMAND
if [ "$1" == "-h" ] ; then
    echo "Usage: `basename $0` [Install NFS Server Script. Run ./install-nfs-server.sh to run the script.]"
    exit 0
fi

#Copy /home to /tmp/home
mkdir /tmp/oldhome |tee -a $log
mv /home/* /tmp/oldhome |tee -a $log
echo "Home successfully backed up." |tee -a $log

#Create new /home
echo -e "nn\np\n\n\nw" | fdisk /dev/sda
echo "New home successfully created." |tee -a $log

partprobe /dev/sda |tee -a $log
# Format your new partition as an ext3 file system
mkfs.xfs /dev/sda4 |tee -a $log
# check the new filesystem
xfs_repair /dev/sda4 |tee -a $log
#Append to /etc/fstab
echo "/dev/sda4         /home       xfs     defaults      0 0" >> /etc/fstab |tee -a $log
# Mount your new partition at a new /home mount point
mount /dev/sda4 /home |tee -a $log
echo "SDA 4 successfully created." |tee -a $log

#Put contents back in /home
mv /tmp/oldhome/* /home |tee -a $log
echo "Home contents successfully moved back." |tee -a $log

#Install nfs-utils
yum install nfs-utils -y |tee -a $log
echo "NFS utils successfully installed." |tee -a $log

#Exportfs commands
echo "/home	10.0.0.0/8(sync,wdelay,hide,no_subtree_check,sec=sys,rw,secure,root_squash,no_all_squash)" >> /etc/exports |tee -a $log
exportfs -a |tee -a $log
echo "Exportfs commands successfully run." |tee -a $log

#Start services
service nfs start |tee -a $log
echo "NFS service started." |tee -a $log

#Firewall rules
firewall-cmd --zone=public --add-port=2049/tcp --permanent |tee -a $log
firewall-cmd --zone=public --add-port=111/tcp --permanent |tee -a $log
firewall-cmd --zone=public --add-port=20048/tcp --permanent |tee -a $log
firewall-cmd --zone=public --add-port=2049/udp --permanent |tee -a $log
firewall-cmd --zone=public --add-port=111/udp --permanent |tee -a $log
firewall-cmd --zone=public --add-port=20048/udp --permanent |tee -a $log

firewall-cmd --reload |tee -a $log
echo "Firewall rules successfully modified." |tee -a $log

#Finished
echo "NFS Server Install successfully completed." |tee -a $log
